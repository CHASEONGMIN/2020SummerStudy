Character.prototype.puppyUpdateTail = function(t) {   //꼬리 애니메이션 
  for (var i=0; i<this.abstract["tail"].children.length; i++) {
    var angleStep = -i*.5;                //앵글 Step 
    var angleAmp = Math.PI/(45/(i+1));   //앵글 Amp
    var rotZ = Math.sin(t+angleStep)*angleAmp;
    var st = this.abstract["tail"].children[i];
    st.rotation.z = rotZ; //(rotY * i);
  }
};

Character.prototype.puppyLick = function() {    //혀 애니메이션
  var _this = this;
  if (!_this.isLicking && Math.random()>.99) {
    this.isLicking = true;
    TweenMax.to (this.meshy["tounge"].scale, 0.7, {z: 6, yoyo: true, repeat: 1, onComplete:function() {
      _this.isLicking = false;
    }, ease: Back.easeOut});
  }
};



