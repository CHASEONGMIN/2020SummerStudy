Puppy = function() { //개의 모델링을 해주는 부분
  this.bodyDimensions = { 
    "body": {  //몸체 관련
      "height": 250,
      "width": 400,
      "depth": 40,
      "position" : { "x": 0, "y": 35, "z": 0 },
      "children": {

        "head": {
          "height": 48,
          "width": 48,
          "depth": 72,
          "position" : { "x": 0, "y": 0, "z": 10 },
          "children" : {
            "skull": {  // 머리 뒤쪽
              "height": 12,
              "width": 12,
              "depth": 12,
              "position" : { "x": 0, "y": 1, "z": -2 },
              "color": 0xFBF7E8
            },
            "face": { //머리 앞쪽
              "height": 6,  
              "width": 6,
              "depth": 6,
              "position" : { "x": 0, "y": -1, "z": 7.5 },
              "color": 0xFBF7E8
            },
            "tounge": { //혀
              "height": 2,
              "width": 1.5,
              "depth": 2,
              "position" : { "x": 0, "y": -3, "z": 9 },
              "color": 0xf72a42
            },
            "leftEar": {
              "height": 10,
              "width": 2,
              "depth": 8,
              "position" : { "x": 6.5, "y": 1, "z": -5 },
              "skew":  [1,    -.2,    0,    0,
              0,    1,    0,    0,
              0,    .2,   1,    0,
              0,    0,    0,    1],
              "color": 0xFF0040   //빨강
            },
            "rightEar": {
              "height": 10,
              "width": 2,
              "depth": 8,
              "position" : { "x": -6.5, "y": 1, "z": -5 },
              "color": 0xFF0040, //빨강
              "skew":  [  1,    .2,   0,    0,
              0,    1,    0,    0,
              0,    .2,   1,    0,
              0,    0,    0,    1],
            },
            "eyes": {
              "height": 3,
              "width": 3,
              "depth": 3,
              "position": { "x": 0, "y": 4, "z": 3 },
              "children": {
                "leftEye": { // 왼쪽 눈
                  "height": 3,
                  "width": 3,
                  "depth": 3,
                  "position" : { "x": -3.5, "y": 0, "z": 0 },
                  "color": 0x333333 // 검정
                },
                "rightEye": { //오른쪽 눈
                  "height": 3,
                  "width": 3,
                  "depth": 3,
                  "position" : { "x": 3.5, "y": 0, "z": 0 },
                  "color": 0x333333 // 검정
                },
              }
            },
            "nose": {
              "height": 3,
              "width": 3,
              "depth": 3,
              "position" : { "x": 0, "y": 0, "z": 12.5 },
              "color": 0x111111
            }
          }
        },

        "torso": {   //몸통
          "height": 30,
          "width": 13,
          "depth": 13,
          "position" : { "x": 0, "y": -20, "z": 0 },
          "skew":    [1,    0,    0,    0,
          0,    1,    0,    0,
          0,    0.4,  1,    0,
          0,    0,    0,    1],
          "color": 0x0101DF //남색
        },

        "rightLeg": {
          "height": 20,
          "width": 7,
          "depth": 7,
          "position" : { "x": -8, "y": -27.5, "z": -6 },
          "children": {
            "thigh": {
              "height": 15,
              "width": 7,
              "depth": 7,
              "position": { "x": -3, "y": 0, "z": 4 },
              "skew":  [1,    -.3,    0,    0,
              0,    1,      0,    0,
              0,    0.5,    1,    0,
              0,    0,      0,    1],
              "color": 0xFBF7E8
            },
            "shin": {
              "height": 15,
              "width": 5,
              "depth": 5,
              "position" : { "x": -4.5, "y": 0, "z": 12 },
              "skew":  [1,    -.1,    0,    0,
              0,    1,      0,    0,
              0,    -0.3,   1,    0,
              0,    0,      0,    1],
              "color": 0xFBF7E8
            },
            "paw": {
              "height": 5,
              "width": 5,
              "depth": 5,
              "position" : { "x": -4, "y": -5, "z": 18 },
              "color": 0xFBF7E8
            }
          }
        },

        "leftLeg": {
          "height": 20,
          "width": 7,
          "depth": 7,
          "position" : { "x": 8, "y": -27.5, "z": -6 },
          "children": {
            "thigh": {
              "height": 15,
              "width": 7,
              "depth": 7,
              "position": { "x": 3, "y": 0, "z": 4 },
              "skew":  [1,    .3,    0,    0,
              0,    1,     0,    0,
              0,    .5,    1,    0,
              0,    0,     0,    1],
              "color": 0xFBF7E8
            },
            "shin": {
              "height": 15,
              "width": 5,
              "depth": 5,
              "position" : { "x": 4.5, "y": 0, "z": 12 },
              "skew":  [1,    .1,    0,    0,
              0,    1,     0,    0,
              0,    -.3,  1,    0,
              0,    0,     0,    1],
              "color": 0xFBF7E8
            },
            "paw": {
              "height": 5,
              "width": 5,
              "depth": 5,
              "position" : { "x": 4, "y": -5, "z": 18 },
              "color": 0xFBF7E8
            }
          }
        },

        "rightArm": {
          "height": 20,
          "width": 5,
          "depth": 5,
          "position" : { "x": -8, "y": -14, "z": 10 },
          "children": {
            "thigh": {
              "height": 13,
              "width": 5,
              "depth": 5,
              "position" : { "x": -0, "y": 0, "z": 0 },
              "skew":  [1,    -.1,    0,    0,
              0,    1,      0,    0,
              0,    -.3,   1,    0,
              0,    0,      0,    1],
              "color": 0xFBF7E8
            },
            "shin": {
              "height": 15,
              "width": 4,
              "depth": 4,
              "position" : { "x": .5, "y": -13.5, "z": 5 },
              "skew":  [1,    0,    0,    0,
              0,    1,      0,    0,
              0,    -.4,    1,    0,
              0,    0,      0,    1],
              "color": 0xFBF7E8
            },
            "paw": {
              "height": 5,
              "width": 5,
              "depth": 5,
              "position" : { "x": .5, "y": -18.5, "z": 10 },
              "color": 0xFBF7E8
            }
          }
        },

        "leftArm": {
          "height": 20,
          "width": 5,
          "depth": 5,
          "position" : { "x": 8, "y": -14, "z": 10 },
          "children": {
            "thigh": {
              "height": 13,
              "width": 5,
              "depth": 5,
              "position" : { "x": -0, "y": 0, "z": 0 },
              "skew":  [1,    .1,    0,    0,
              0,    1,      0,    0,
              0,    -.3,   1,    0,
              0,    0,      0,    1],
              "color": 0xFBF7E8
            },
            "shin": {
              "height": 15,
              "width": 4,
              "depth": 4,
              "position" : { "x": -.5, "y": -13.5, "z": 5 },
              "skew":  [1,    0,    0,    0,
              0,    1,      0,    0,
              0,    -.4,    1,    0,
              0,    0,      0,    1],
              "color": 0xFBF7E8
            },
            "paw": {
              "height": 5,
              "width": 5,
              "depth": 5,
              "position" : { "x": -.5, "y": -18.5, "z": 10 },
              "color": 0xFBF7E8
            }
          }
        },

        "tail": {
          "height": 6,
          "width": 2,
          "depth": 2,
          "position" : { "x": 0, "y": -32, "z": -14 },
          "children": {
            "one": {
              "height": 6,
              "width": 2,
              "depth": 2,
              "position": { "x":0, "y": 0, "z": 0 },
              "rotate": { "x":100, "y": 0, "z": 0 },
              "color": 0xFBF7E8
            }
          }
        }
      }
    }
  };

  return this.bodyDimensions;
};
