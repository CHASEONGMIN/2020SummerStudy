input_data = [10, 9 ,8, 7, 6, 5, 4, 3, -3, -3, 4, 4]

for i in list(set(input_data)):
    input_data.remove(i)
print(set(input_data))