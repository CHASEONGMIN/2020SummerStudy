f= open("a.dat", "r")
r=[]
c=[]
v=[]

while True:

    x = f.readline()
    if not x: break
    x = x.split()

    for y in x:
        r_index=y.split(',')
        r.append(r_index[0])
        r_index.remove(r_index[0])
        c_index=r_index[0].split(':')
        c.append(int(c_index[0]))
        v.append(int(c_index[1]))

r.sort(reverse=True)
c.sort(reverse=True)

print("maximum row :", r[0])
print("maximum column :", c[0])
