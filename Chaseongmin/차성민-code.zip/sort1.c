#include "header.h"
void sort1(int *a, int n){
    int i, j, move;
    int val;

    for(i=1; i<n; i++){
       val = a[i];
       j = i;
       if( a[j-1] > val )
          move = true;
       else
          move = false;

       while( move ) {
          a[j] = a[j-1];
          j = j - 1;
          if( j >0 && a[j-1] > val )
             move = true;
          else
             move = false;
        }
        a[j] = val;
    }
}
