#include<stdio.h>
#include<stdlib.h>

#define true  1
#define false 0

void print_array( int *a, int n) {
    for( int i=0; i<n; i++) 
        printf("%d ", a[i]);
}

void get_value(int *a, int n) {
    for(int i=0; i <n; i++)
        a[i] = rand() % 100;
}

void sort1(int *a, int n){
    int i, j, move;
    int val;
    
    for(i=1; i<n; i++){
       val = a[i];
       j = i;
       if( a[j-1] > val ) 
          move = true;
       else
          move = false;
       
       while( move ) {
          a[j] = a[j-1];
          j = j - 1;
          if( j >0 && a[j-1] > val )
             move = true;
          else
             move = false;
        }
        a[j] = val;
    }
}

void sort2(int *a, int n){
    int i, j;
    int val;
    for(i=n-1; i > 0; i--){
        for(j=0; j<i; j++){
            if( a[j] > a[j+1] ) {
                val = a[j];
                a[j] = a[j+1];
                a[j+1] = val;
            }
        }
    }
}

void sort3(int *a, int n){
    int i, j, least;
    int val;

    for(i = 0;  i <n-1; i++){
        least = i;
        for( j = i + 1; j < n; j++)
            if( a[j] < a[least] ) least = j;
        val = a[least];
        a[least] = a[i];
        a[i] = val;
    }
}


void swap(int* a, int* b)
{
    int t = *a;
    *a = *b;
    *b = t;
}

int part(int arr[], int low, int high)
{
    int pivot = arr[high];    
    int i = (low - 1);  

    for (int j = low; j <= high- 1; j++)
    {
        if (arr[j] <= pivot)
        {
            i++;    
            swap(&arr[i], &arr[j]);
        }
    }
    swap(&arr[i + 1], &arr[high]);
    return (i + 1);
}

void sort4(int arr[], int low, int high)
{
    if (low < high)
    {
        int pi = part(arr, low, high);

        sort4(arr, low, pi - 1);  
        sort4(arr, pi + 1, high); 
    }
}

int main(){
    int a[7];
    int n = 7;

    get_value(a, n);
    printf("Way 1 : ");
    print_array(a, n);
    sort1(a, n);
    printf(" ==> ");
    print_array(a, n);
    printf("\n");

    get_value(a, n);
    printf("Way 2 :");
    print_array(a, n);
    sort2(a, n);
    printf(" ==> ");
    print_array(a, n);
    printf("\n");

    get_value(a, n);
    printf("Way 3 :");
    print_array(a, n);
    sort3(a, n);
    printf(" ==> ");
    print_array(a, n);
    printf("\n");
    
    get_value(a, n);
    printf("Way 4 :");
    print_array(a, n);
    sort4( a, 0, 6);
    printf(" ==> ");
    print_array(a, n);
    printf("\n");

    return 1;
}
