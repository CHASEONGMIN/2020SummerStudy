#include<stdio.h>
#include<stdlib.h>

#define true  1
#define false 0


void print_array( int *a, int n);
void get_value(int *a, int n);
void sort1(int *a, int n);
void sort2(int *a, int n);
void sort3(int *a, int n);
void swap(int* a, int* b);
int part(int arr[], int low, int high);
void sort4(int arr[], int low, int high);

