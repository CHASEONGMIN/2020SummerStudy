#include "header.h"


int main(){
    int a[7];
    int n = 7;

    get_value(a, n);
    printf("Way 1 : ");
    print_array(a, n);
    sort1(a, n);
    printf(" ==> ");
    print_array(a, n);
    printf("\n");

    get_value(a, n);
    printf("Way 2 :");
    print_array(a, n);
    sort2(a, n);
    printf(" ==> ");
    print_array(a, n);
    printf("\n");

    get_value(a, n);
    printf("Way 3 :");
    print_array(a, n);
    sort3(a, n);
    printf(" ==> ");
    print_array(a, n);
    printf("\n");

    get_value(a, n);
    printf("Way 4 :");
    print_array(a, n);
    sort4( a, 0, 6);
    printf(" ==> ");
    print_array(a, n);
    printf("\n");

    return 1;
}

