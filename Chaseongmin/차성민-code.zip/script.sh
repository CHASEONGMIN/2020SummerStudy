#!/bin/bash 
for i in $(ls)
do
	echo $i $(stat -c%s $i)
done
