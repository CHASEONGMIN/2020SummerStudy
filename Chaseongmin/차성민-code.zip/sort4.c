#include "header.h"

void sort4(int arr[], int low, int high)
{
    if (low < high)
    {
        int pi = part(arr, low, high);

        sort4(arr, low, pi - 1);
        sort4(arr, pi + 1, high);
    }
}

