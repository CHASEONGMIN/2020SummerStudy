#include "header.h"


void sort3(int *a, int n){
    int i, j, least;
    int val;

    for(i = 0;  i <n-1; i++){
        least = i;
        for( j = i + 1; j < n; j++)
            if( a[j] < a[least] ) least = j;
        val = a[least];
        a[least] = a[i];
        a[i] = val;
    }
}
